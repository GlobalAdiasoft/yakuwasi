<?php
class Ventas_controller extends Controller {
    public function __construct() {
        parent::__construct();
    }
    public function mostrar() {
       
        if(empty($_GET['fechainicio']) && empty($_GET['fechafinal'])){
            $facturas = Facturas::getAll();
            //echo 'estan vacias';
        }else{
         if(!empty($_GET['fechainicio']) && empty($_GET['fechafinal'])){
            $facturas = Facturas::getAll();
            //echo 'fecha final vacia';
        }
          if(empty($_GET['fechainicio']) && !empty($_GET['fechafinal'])){
            $facturas = Facturas::getAll();
            //echo 'fecha inicial vacia';
        }
           if(!empty($_GET['fechainicio']) && !empty($_GET['fechafinal'])){
            $facturas = Facturas::whereBetween('fact_fecha', $_GET['fechainicio'], $_GET['fechafinal']);
            //echo 'fechas llenas';
        }
        }
        
        
         $data_general=array();
         
        foreach ($facturas as $value) {
            $pedidos=$value['fact_pedido_usuario'];
            $pedidos= explode('/', $pedidos);
            $usuarios = Usuario::getBy('usu_usuario', $pedidos[1]);
            $datos_pedidos = array(
                'ped_id_pedidos_doc'=>$pedidos[0],
                'ped_usuario'=>$usuarios->getId(),
                );
            $pedidos = Pedidos::whereV($datos_pedidos, 'and');
          
            foreach ($pedidos as $value_pedidos) {
                if(empty($_GET['pro_busqueda'])){
                $usuario= Usuario::getById($value_pedidos['ped_usuario']);
                array_push($data_general, array(
                 "fecha"=>   mb_strtoupper($value['fact_fecha']),
                 "nombre_producto"=> mb_strtoupper($value_pedidos['ped_nombre_pro']),
                 "usuario"=> mb_strtoupper($usuario->getUsu_usuario()),
                 "codigo_producto"=> mb_strtoupper($value_pedidos['ped_cod_pro']),    
                         
                 "cantidad"=>mb_strtoupper($value_pedidos['ped_cantidad']),
                 "valor_sin_igv"=>mb_strtoupper(number_format((float) $value_pedidos['ped_valor_venta_sin_igv']*1.18, 2, '.', ',')),
                    
                 "correlativo"=>mb_strtoupper($value['fac_correlativo']),
                 "numero_factura"=>mb_strtoupper($value['fac_numero_factura']),
                 "total"=>mb_strtoupper(number_format((float) ($value_pedidos['ped_valor_venta_sin_igv']*1.18)*$value_pedidos['ped_cantidad'], 2, '.', ',')),
              ));                           
                }else{
                    if($_GET['pro_busqueda']==$value_pedidos['ped_cod_pro']){
                         $usuario= Usuario::getById($value_pedidos['ped_usuario']);
                array_push($data_general, array(
                 "fecha"=>   mb_strtoupper($value['fact_fecha']),
                 "nombre_producto"=> mb_strtoupper($value_pedidos['ped_nombre_pro']),
                 "usuario"=> mb_strtoupper($usuario->getUsu_usuario()),
                 "codigo_producto"=> mb_strtoupper($value_pedidos['ped_cod_pro']),    
                         
                 "cantidad"=>mb_strtoupper($value_pedidos['ped_cantidad']),
                 "valor_sin_igv"=>mb_strtoupper(number_format((float) $value_pedidos['ped_valor_venta_sin_igv']*1.18, 2, '.', ',')),
                 "correlativo"=>mb_strtoupper($value['fac_correlativo']),
                 "numero_factura"=>mb_strtoupper($value['fac_numero_factura']),
                 "total"=>mb_strtoupper(number_format((float) ($value_pedidos['ped_valor_venta_sin_igv']*1.18)*$value_pedidos['ped_cantidad'], 2, '.', ',')),
              )); 
                    }
                }
            }
        }
         echo json_encode($data_general,JSON_PRETTY_PRINT   );
    }
    public function productos_busqueda(){
        $articulos= Articulos::getAll();
        $i = 0;
        foreach ($articulos as $value) {
            $i++;
            echo '<option value="'.$value['art_codigo'].'">'.$value['art_codigo'].' - '.$value['art_nombre'].'</option>';
            
        }
    }
    public function item_valorizado(){
          
        if(empty($_GET['fechainicio']) && empty($_GET['fechafinal'])){
            $facturas = Facturas::getAll();
            //echo 'estan vacias';
        }else{
         if(!empty($_GET['fechainicio']) && empty($_GET['fechafinal'])){
            $facturas = Facturas::getAll();
            //echo 'fecha final vacia';
        }
          if(empty($_GET['fechainicio']) && !empty($_GET['fechafinal'])){
            $facturas = Facturas::getAll();
            //echo 'fecha inicial vacia';
        }
           if(!empty($_GET['fechainicio']) && !empty($_GET['fechafinal'])){
            $facturas = Facturas::whereBetween('fact_fecha', $_GET['fechainicio'], $_GET['fechafinal']);
            //echo 'fechas llenas';
        }
        }
  $data_general=array();
  $total = 0;       
        foreach ($facturas as $value) {
            $pedidos=$value['fact_pedido_usuario'];
            $pedidos= explode('/', $pedidos);
            $usuarios = Usuario::getBy('usu_usuario', $pedidos[1]);
            $datos_pedidos = array(
                'ped_id_pedidos_doc'=>$pedidos[0],
                'ped_usuario'=>$usuarios->getId(),
                );
            $pedidos = Pedidos::whereV($datos_pedidos, 'and');
            
            foreach ($pedidos as $value_pedidos) {
                if(empty($_GET['pro_busqueda'])){  
                 $total_item = ($value_pedidos['ped_valor_venta_sin_igv']*1.18)*$value_pedidos['ped_cantidad'];
                 $total = $total + $total_item ; 
                                    
                }else{
                    if($_GET['pro_busqueda']==$value_pedidos['ped_cod_pro']){
                    $total_item = ($value_pedidos['ped_valor_venta_sin_igv']*1.18)*$value_pedidos['ped_cantidad'];
                    $total = $total + $total_item ; 
                    }
                }
            }
        }
        $total = $total;
        $subtotal = $total / 1.18;
        $igv = $total - $subtotal;
    
        $data_general['total']= number_format((float) $total, 2, '.', ',');
        $data_general['subtotal'] =number_format((float) $subtotal, 2, '.', ',');
        $data_general['igv'] = number_format((float) $igv, 2, '.', ',');
        
         echo json_encode($data_general,JSON_PRETTY_PRINT   );
    }
}
