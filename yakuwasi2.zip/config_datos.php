<?php
define('CONFIGHOSTING', '');
define('CONFIGHOSTING_CORREO', '');
define('NOMBRE_LOGO', 'logo.png');
define('NOMBRE_FAVICON', 'favicon.png');

define('NOMBRE_EMPRESA', 'YAKUWASI');
define('DIRECCION_EMPRESA','urb bancarios');
define('RUC_EMPRESA','104544639028');
define('UBIGEO_EMPRESA','104544639028');



define('NOMBRE_SESSION', 'YAKUWASI');

define('NOMBRE_DOMINIO', '');
define('AUTHOR', 'Marco Antonio Rodriguez Salinas');
define('DESCRIPTION', '');
define('KEYWORDS', '');
define('VERSION', '1.0');
//Meta_Datos_facebook
define('META_FACEBOOK_URL',NOMBRE_EMPRESA.NOMBRE_DOMINIO);
define('META_FACEBOOK_TYPE','');
define('META_FACEBOOK_TITULO','');
define('META_FACEBOOK_DESCRIPCION','');
define('META_FACEBOOK_IMG','');


