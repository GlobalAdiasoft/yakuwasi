<?php

class Plecompras extends Model {
  protected static $table = "t_plecompras";
   private $id;
   private $plec_1;
   private $plec_2;
   private $plec_3;
   private $plec_4;
   private $plec_5;
   private $plec_6;
   private $plec_7;
   private $plec_8;
   private $plec_9;
   private $plec_10;
   private $plec_11;
   private $plec_12;
   private $plec_13;
   private $plec_14;
   private $plec_15;
   private $plec_16;
   private $plec_17;
   private $plec_18;
   private $plec_19;
   private $plec_20;
   private $plec_21;
   private $plec_22;
   private $plec_23;
   private $plec_24;
   private $plec_25;
   private $plec_26;
   private $plec_27;
   private $plec_28;
   private $plec_29;
   private $plec_30;
   private $plec_31;
   private $plec_32;
   function __construct($id, $plec_1, $plec_2, $plec_3, $plec_4, $plec_5, $plec_6, $plec_7, $plec_8, $plec_9, $plec_10, $plec_11, $plec_12, $plec_13, $plec_14, $plec_15, $plec_16, $plec_17, $plec_18, $plec_19, $plec_20, $plec_21, $plec_22, $plec_23, $plec_24, $plec_25, $plec_26, $plec_27, $plec_28, $plec_29, $plec_30, $plec_31, $plec_32) {
       $this->id = $id;
       $this->plec_1 = $plec_1;
       $this->plec_2 = $plec_2;
       $this->plec_3 = $plec_3;
       $this->plec_4 = $plec_4;
       $this->plec_5 = $plec_5;
       $this->plec_6 = $plec_6;
       $this->plec_7 = $plec_7;
       $this->plec_8 = $plec_8;
       $this->plec_9 = $plec_9;
       $this->plec_10 = $plec_10;
       $this->plec_11 = $plec_11;
       $this->plec_12 = $plec_12;
       $this->plec_13 = $plec_13;
       $this->plec_14 = $plec_14;
       $this->plec_15 = $plec_15;
       $this->plec_16 = $plec_16;
       $this->plec_17 = $plec_17;
       $this->plec_18 = $plec_18;
       $this->plec_19 = $plec_19;
       $this->plec_20 = $plec_20;
       $this->plec_21 = $plec_21;
       $this->plec_22 = $plec_22;
       $this->plec_23 = $plec_23;
       $this->plec_24 = $plec_24;
       $this->plec_25 = $plec_25;
       $this->plec_26 = $plec_26;
       $this->plec_27 = $plec_27;
       $this->plec_28 = $plec_28;
       $this->plec_29 = $plec_29;
       $this->plec_30 = $plec_30;
       $this->plec_31 = $plec_31;
       $this->plec_32 = $plec_32;
   }
   function getId() {
       return $this->id;
   }

   function getPlec_1() {
       return $this->plec_1;
   }

   function getPlec_2() {
       return $this->plec_2;
   }

   function getPlec_3() {
       return $this->plec_3;
   }

   function getPlec_4() {
       return $this->plec_4;
   }

   function getPlec_5() {
       return $this->plec_5;
   }

   function getPlec_6() {
       return $this->plec_6;
   }

   function getPlec_7() {
       return $this->plec_7;
   }

   function getPlec_8() {
       return $this->plec_8;
   }

   function getPlec_9() {
       return $this->plec_9;
   }

   function getPlec_10() {
       return $this->plec_10;
   }

   function getPlec_11() {
       return $this->plec_11;
   }

   function getPlec_12() {
       return $this->plec_12;
   }

   function getPlec_13() {
       return $this->plec_13;
   }

   function getPlec_14() {
       return $this->plec_14;
   }

   function getPlec_15() {
       return $this->plec_15;
   }

   function getPlec_16() {
       return $this->plec_16;
   }

   function getPlec_17() {
       return $this->plec_17;
   }

   function getPlec_18() {
       return $this->plec_18;
   }

   function getPlec_19() {
       return $this->plec_19;
   }

   function getPlec_20() {
       return $this->plec_20;
   }

   function getPlec_21() {
       return $this->plec_21;
   }

   function getPlec_22() {
       return $this->plec_22;
   }

   function getPlec_23() {
       return $this->plec_23;
   }

   function getPlec_24() {
       return $this->plec_24;
   }

   function getPlec_25() {
       return $this->plec_25;
   }

   function getPlec_26() {
       return $this->plec_26;
   }

   function getPlec_27() {
       return $this->plec_27;
   }

   function getPlec_28() {
       return $this->plec_28;
   }

   function getPlec_29() {
       return $this->plec_29;
   }

   function getPlec_30() {
       return $this->plec_30;
   }

   function getPlec_31() {
       return $this->plec_31;
   }

   function getPlec_32() {
       return $this->plec_32;
   }

   function setId($id) {
       $this->id = $id;
   }

   function setPlec_1($plec_1) {
       $this->plec_1 = $plec_1;
   }

   function setPlec_2($plec_2) {
       $this->plec_2 = $plec_2;
   }

   function setPlec_3($plec_3) {
       $this->plec_3 = $plec_3;
   }

   function setPlec_4($plec_4) {
       $this->plec_4 = $plec_4;
   }

   function setPlec_5($plec_5) {
       $this->plec_5 = $plec_5;
   }

   function setPlec_6($plec_6) {
       $this->plec_6 = $plec_6;
   }

   function setPlec_7($plec_7) {
       $this->plec_7 = $plec_7;
   }

   function setPlec_8($plec_8) {
       $this->plec_8 = $plec_8;
   }

   function setPlec_9($plec_9) {
       $this->plec_9 = $plec_9;
   }

   function setPlec_10($plec_10) {
       $this->plec_10 = $plec_10;
   }

   function setPlec_11($plec_11) {
       $this->plec_11 = $plec_11;
   }

   function setPlec_12($plec_12) {
       $this->plec_12 = $plec_12;
   }

   function setPlec_13($plec_13) {
       $this->plec_13 = $plec_13;
   }

   function setPlec_14($plec_14) {
       $this->plec_14 = $plec_14;
   }

   function setPlec_15($plec_15) {
       $this->plec_15 = $plec_15;
   }

   function setPlec_16($plec_16) {
       $this->plec_16 = $plec_16;
   }

   function setPlec_17($plec_17) {
       $this->plec_17 = $plec_17;
   }

   function setPlec_18($plec_18) {
       $this->plec_18 = $plec_18;
   }

   function setPlec_19($plec_19) {
       $this->plec_19 = $plec_19;
   }

   function setPlec_20($plec_20) {
       $this->plec_20 = $plec_20;
   }

   function setPlec_21($plec_21) {
       $this->plec_21 = $plec_21;
   }

   function setPlec_22($plec_22) {
       $this->plec_22 = $plec_22;
   }

   function setPlec_23($plec_23) {
       $this->plec_23 = $plec_23;
   }

   function setPlec_24($plec_24) {
       $this->plec_24 = $plec_24;
   }

   function setPlec_25($plec_25) {
       $this->plec_25 = $plec_25;
   }

   function setPlec_26($plec_26) {
       $this->plec_26 = $plec_26;
   }

   function setPlec_27($plec_27) {
       $this->plec_27 = $plec_27;
   }

   function setPlec_28($plec_28) {
       $this->plec_28 = $plec_28;
   }

   function setPlec_29($plec_29) {
       $this->plec_29 = $plec_29;
   }

   function setPlec_30($plec_30) {
       $this->plec_30 = $plec_30;
   }

   function setPlec_31($plec_31) {
       $this->plec_31 = $plec_31;
   }

   function setPlec_32($plec_32) {
       $this->plec_32 = $plec_32;
   }

      public function getMyVars() {
        return get_object_vars($this);
    }
}
